import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, CheckCircle2, Loader2, Calendar, User, Mail, Phone, MessageSquare, ChevronDown } from 'lucide-react';

const services = [
  'Prenatal Checkup (Antenatal Care)',
  'Gynecology Consultation',
  'Infertility Treatment',
  'Diabetes Management',
  'High-Risk Pregnancy Care',
  'Postnatal Care',
  'Menstrual Disorder Treatment',
  'PCOS/Thyroid Management',
  'Family Planning Services',
  'General Physician Consultation',
];

export default function AppointmentForm() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    date: '',
    message: ''
  });

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setStatus('success');
    setTimeout(() => setStatus('idle'), 5000);
  };

  return (
    <section id="contact" className="py-24 bg-transparent overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-20 lg:gap-16 items-center">
          {/* Form Column */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-primary-start font-bold tracking-wider uppercase text-sm mb-4 block">
              Book Now
            </span>
            <h2 className="text-4xl lg:text-5xl font-display font-bold text-dark-text mb-8 leading-tight">
              Ready to <span className="text-gradient">Get Quality Care?</span>
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-light-text group-focus-within:text-primary-start transition-colors" size={20} />
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    className="w-full pl-12 pr-4 py-4 bg-soft-bg border border-transparent rounded-2xl focus:border-primary-start focus:bg-white focus:ring-4 focus:ring-primary-start/10 outline-none transition-all"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div className="relative group">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-light-text group-focus-within:text-primary-start transition-colors" size={20} />
                  <input
                    type="email"
                    required
                    placeholder="Email Address"
                    className="w-full pl-12 pr-4 py-4 bg-soft-bg border border-transparent rounded-2xl focus:border-primary-start focus:bg-white focus:ring-4 focus:ring-primary-start/10 outline-none transition-all"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div className="relative group">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-light-text group-focus-within:text-primary-start transition-colors" size={20} />
                  <input
                    type="tel"
                    required
                    placeholder="Phone Number"
                    className="w-full pl-12 pr-4 py-4 bg-soft-bg border border-transparent rounded-2xl focus:border-primary-start focus:bg-white focus:ring-4 focus:ring-primary-start/10 outline-none transition-all"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
                <div className="relative group">
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-light-text pointer-events-none" size={20} />
                  <select
                    required
                    className="w-full px-4 py-4 bg-soft-bg border border-transparent rounded-2xl focus:border-primary-start focus:bg-white focus:ring-4 focus:ring-primary-start/10 outline-none transition-all appearance-none text-light-text"
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                  >
                    <option value="" disabled>Select Service</option>
                    {services.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              <div className="relative group">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-light-text group-focus-within:text-primary-start transition-colors" size={20} />
                <input
                  type="date"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-soft-bg border border-transparent rounded-2xl focus:border-primary-start focus:bg-white focus:ring-4 focus:ring-primary-start/10 outline-none transition-all text-light-text"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                />
              </div>

              <div className="relative group">
                <MessageSquare className="absolute left-4 top-6 text-light-text group-focus-within:text-primary-start transition-colors" size={20} />
                <textarea
                  placeholder="Your Message (Optional)"
                  rows={4}
                  className="w-full pl-12 pr-4 py-4 bg-soft-bg border border-transparent rounded-2xl focus:border-primary-start focus:bg-white focus:ring-4 focus:ring-primary-start/10 outline-none transition-all resize-none"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                />
              </div>

              <button
                type="submit"
                disabled={status !== 'idle'}
                className="w-full gradient-bg text-white py-5 rounded-2xl font-bold shadow-xl hover:shadow-primary-start/40 transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center space-x-3 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {status === 'loading' ? (
                  <>
                    <Loader2 className="animate-spin" size={24} />
                    <span>Processing...</span>
                  </>
                ) : status === 'success' ? (
                  <>
                    <CheckCircle2 size={24} />
                    <span>Appointment Requested!</span>
                  </>
                ) : (
                  <>
                    <Send size={24} />
                    <span>Book My Appointment</span>
                  </>
                )}
              </button>
            </form>
          </motion.div>

          {/* Image Column */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="rounded-[3rem] overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/3985164/pexels-photo-3985164.jpeg"
                alt="Doctor Consultation"
                className="w-full h-auto object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            
            {/* Floating Info */}
            <div className="absolute -bottom-10 -right-10 glass-card p-8 rounded-3xl hidden md:block">
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-primary-start/10 rounded-full flex items-center justify-center text-primary-start">
                    <Phone size={20} />
                  </div>
                  <div>
                    <p className="text-xs text-light-text font-bold uppercase">Call Us</p>
                    <p className="font-bold text-dark-text">+91 97391 36066</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-primary-start/10 rounded-full flex items-center justify-center text-primary-start">
                    <Mail size={20} />
                  </div>
                  <div>
                    <p className="text-xs text-light-text font-bold uppercase">Email Us</p>
                    <p className="font-bold text-dark-text">vrfamilyclinic@gmail.com</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
