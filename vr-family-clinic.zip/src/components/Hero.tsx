import { motion } from 'motion/react';
import { Calendar, ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-28 lg:pt-20 overflow-hidden">
      {/* Background Overlay for text readability */}
      <div className="absolute inset-0 bg-linear-to-b from-primary-start/80 to-primary-start/10 -z-10" />
      
      {/* Animated Shapes */}
      <motion.div
        animate={{
          y: [0, -20, 0],
          rotate: [0, 10, 0],
        }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-1/4 left-10 w-32 h-32 bg-white/10 rounded-full blur-3xl -z-10"
      />
      <motion.div
        animate={{
          y: [0, 30, 0],
          rotate: [0, -15, 0],
        }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-1/4 right-10 w-64 h-64 bg-white/5 rounded-full blur-3xl -z-10"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-12 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-block px-4 py-1.5 rounded-full bg-white/20 text-white font-semibold text-sm mb-6 backdrop-blur-md"
            >
              Comprehensive Women’s & Family Care
            </motion.span>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-display font-bold text-white leading-tight mb-6">
              VR Family <br />
              <span className="text-white/90 text-4xl lg:text-5xl block mt-2">Clinic</span>
            </h1>
            <p className="text-lg lg:text-xl text-white/80 mb-6 max-w-lg leading-relaxed">
              Specialized care for women’s health, pregnancy management, and general medical conditions.
            </p>
            
            <div className="flex flex-col space-y-3 mb-10 text-white/90">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                </div>
                <span className="font-medium">Yelahanka New Town, Bengaluru</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
                <span className="font-medium">Mon–Sat: 9 AM – 9 PM | Sun: 10 AM – 2 PM</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
              <a
                href="#contact"
                className="w-full sm:w-auto bg-white text-primary-start px-8 py-4 rounded-full font-bold shadow-2xl hover:bg-soft-bg transition-all hover:scale-105 active:scale-95 flex items-center justify-center space-x-2"
              >
                <Calendar size={20} />
                <span>Book Appointment</span>
              </a>
              <a
                href="#services"
                className="w-full sm:w-auto border-2 border-white/30 text-white px-8 py-4 rounded-full font-bold hover:bg-white/10 transition-all flex items-center justify-center space-x-2"
              >
                <span>Learn More</span>
                <ArrowRight size={20} />
              </a>
            </div>

            {/* Trust Badges */}
            <div className="mt-12 flex flex-wrap items-center gap-6 sm:gap-8">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <img
                    key={i}
                    src={[
                      'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
                      'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
                      'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
                      'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg'
                    ][i-1]}
                    alt="User"
                    className="w-10 h-10 rounded-full border-2 border-white shadow-lg object-cover"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
              <div>
                <p className="text-white font-bold text-lg">5000+</p>
                <p className="text-white/60 text-sm">Happy Patients</p>
              </div>
            </div>
          </motion.div>

          {/* Hero Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="relative"
          >
            <div className="relative z-10 rounded-[2rem] overflow-hidden shadow-2xl border-8 border-white/10">
              <img
                src="https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg"
                alt="Family Clinic"
                className="w-full h-auto object-cover hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            
            {/* Floating Card */}
            <motion.div
              animate={{ y: [0, -15, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-6 -left-6 z-20 glass-card p-6 rounded-2xl hidden md:block"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <p className="font-bold text-dark-text">Certified Care</p>
                  <p className="text-xs text-light-text">Top Rated Clinic 2024</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Wave Divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 120L60 110C120 100 240 80 360 73.3C480 66.7 600 73.3 720 80C840 86.7 960 93.3 1080 86.7C1200 80 1320 60 1380 50L1440 40V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="#F7FAFF"/>
        </svg>
      </div>
    </section>
  );
}
