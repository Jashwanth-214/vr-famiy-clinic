import { motion } from 'motion/react';
import { Calendar, ArrowRight } from 'lucide-react';

const posts = [
  {
    id: 1,
    title: 'Essential Prenatal Care Tips for Expecting Mothers',
    category: 'Pregnancy',
    date: 'March 15, 2024',
    image: 'https://images.pexels.com/photos/7055925/pexels-photo-7055925.jpeg',
    excerpt: 'Monitoring your health and your baby’s development is crucial. Learn about the key assessments during prenatal checkups.'
  },
  {
    id: 2,
    title: 'Managing Type-2 Diabetes: A Family Approach',
    category: 'Health',
    date: 'March 10, 2024',
    image: 'https://images.pexels.com/photos/6823336/pexels-photo-6823336.jpeg',
    excerpt: 'Diabetes management goes beyond medication. Discover how lifestyle changes and family support can make a difference.'
  },
  {
    id: 3,
    title: 'Understanding PCOS and Women’s Reproductive Health',
    category: 'Gynecology',
    date: 'March 5, 2024',
    image: 'https://images.pexels.com/photos/3845126/pexels-photo-3845126.jpeg',
    excerpt: 'PCOS is a common endocrine disorder. Learn about the symptoms, diagnosis, and specialized treatment options available.'
  }
];

export default function Blog() {
  return (
    <section id="blog" className="py-24 bg-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
          <div className="mb-8 md:mb-0">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-primary-start font-bold tracking-wider uppercase text-sm mb-4 block"
            >
              Family Health Guide
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-4xl lg:text-5xl font-display font-bold text-dark-text"
            >
              Latest from <span className="text-gradient">Our Blog</span>
            </motion.h2>
          </div>
          <motion.button
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex items-center space-x-2 text-primary-start font-bold hover:space-x-4 transition-all"
          >
            <span>View All Articles</span>
            <ArrowRight size={20} />
          </motion.button>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {posts.map((post, index) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-[2.5rem] overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100"
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 px-4 py-1.5 bg-white/90 backdrop-blur-md rounded-full text-primary-start text-xs font-bold shadow-lg">
                  {post.category}
                </div>
              </div>
              <div className="p-8">
                <div className="flex items-center space-x-2 text-light-text text-sm mb-4">
                  <Calendar size={16} />
                  <span>{post.date}</span>
                </div>
                <h3 className="text-2xl font-bold text-dark-text mb-4 group-hover:text-primary-start transition-colors leading-tight">
                  {post.title}
                </h3>
                <p className="text-light-text mb-6 line-clamp-2">
                  {post.excerpt}
                </p>
                <button className="flex items-center space-x-2 text-primary-start font-bold hover:space-x-4 transition-all">
                  <span>Read More</span>
                  <ArrowRight size={18} />
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
