import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'What is included in a prenatal checkup?',
    answer: 'Prenatal checkups include routine pregnancy monitoring, antenatal assessments, medical consultations, screening for pregnancy-related conditions, and guidance to support a healthy pregnancy journey.'
  },
  {
    question: 'Do you handle high-risk pregnancies?',
    answer: 'Yes, we provide specialized care for high-risk pregnancies, which includes closer monitoring and intensive medical supervision to manage potential complications.'
  },
  {
    question: 'What are your clinic timings?',
    answer: 'The clinic operates from 9:00 AM to 9:00 PM from Monday to Saturday, and 10:00 AM to 2:00 PM on Sundays.'
  },
  {
    question: 'Do you offer infertility treatments?',
    answer: 'Yes, we provide personalized medical solutions for couples trying to conceive, led by our experienced infertility specialists.'
  },
  {
    question: 'How can I book an appointment?',
    answer: 'You can book an appointment through our website or by contacting us via phone or WhatsApp at +91 97391 36066.'
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-transparent">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-primary-start font-bold tracking-wider uppercase text-sm mb-4 block"
          >
            Common Questions
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl lg:text-5xl font-display font-bold text-dark-text mb-6"
          >
            Everything You Need to <span className="text-gradient">Know About Our Care</span>
          </motion.h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`rounded-3xl border transition-all duration-300 ${
                openIndex === index ? 'border-primary-start bg-soft-bg/80 backdrop-blur-md shadow-lg' : 'border-gray-100 bg-white/50 backdrop-blur-sm hover:border-primary-start/30'
              }`}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-8 py-6 flex items-center justify-between text-left"
              >
                <span className="text-lg font-bold text-dark-text">{faq.question}</span>
                <motion.div
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  className={`text-primary-start transition-colors ${openIndex === index ? 'text-primary-start' : 'text-light-text'}`}
                >
                  <ChevronDown size={24} />
                </motion.div>
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="px-8 pb-8 text-light-text leading-relaxed">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
