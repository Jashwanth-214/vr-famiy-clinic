import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ArrowRight, User, Sparkles, ShieldCheck, HeartPulse, Activity, Zap } from 'lucide-react';

const services = [
  {
    id: 1,
    title: 'Prenatal Checkup (Antenatal Care)',
    icon: <HeartPulse />,
    image: 'https://images.pexels.com/photos/19550812/pexels-photo-19550812.jpeg',
    description: 'Routine monitoring, assessments, and guidance to support a healthy pregnancy journey.',
    fullDescription: 'Prenatal checkups include routine pregnancy monitoring, antenatal assessments, medical consultations, and screening for pregnancy-related conditions to ensure the safety of both mother and baby.',
    steps: ['Routine Monitoring', 'Antenatal Assessment', 'Medical Consultation', 'Screening'],
    recovery: 'Regular visits throughout pregnancy are recommended for optimal health management.',
    sourceUrl: 'https://www.pexels.com/photo/a-woman-is-holding-a-baby-s-head-while-another-person-is-holding-a-syringe-19550812/'
  },
  {
    id: 2,
    title: 'Gynecology & Women’s Health',
    icon: <User />,
    image: 'https://images.pexels.com/photos/2617210/pexels-photo-2617210.jpeg',
    description: 'Comprehensive care for reproductive health, including treatment for menstrual disorders and PCOS.',
    fullDescription: 'We provide specialized care for women’s health, addressing menstrual disorders, irregular periods, and endocrine disorders like thyroid problems and PCOS.',
    steps: ['Consultation', 'Diagnosis', 'Treatment Plan', 'Follow-up'],
    recovery: 'Personalized care plans ensure long-term health and wellbeing.',
    sourceUrl: 'https://images.pexels.com/photos/2617210/pexels-photo-2617210.jpeg'
  },
  {
    id: 3,
    title: 'Infertility Treatment',
    icon: <Sparkles />,
    image: 'https://images.pexels.com/photos/8680336/pexels-photo-8680336.jpeg',
    description: 'Personalized medical solutions for couples trying to conceive, led by experienced specialists.',
    fullDescription: 'Our infertility specialists offer personalized medical solutions and support for couples on their journey to parenthood.',
    steps: ['Evaluation', 'Hormonal Assessment', 'Personalized Strategy', 'Ongoing Support'],
    recovery: 'Treatment duration varies based on individual needs and medical history.',
    sourceUrl: 'https://images.pexels.com/photos/8680336/pexels-photo-8680336.jpeg'
  },
  {
    id: 4,
    title: 'Diabetes Management',
    icon: <Activity />,
    image: 'https://images.pexels.com/photos/6823336/pexels-photo-6823336.jpeg',
    description: 'Specialized diagnosis and management for Type-2 diabetes and general family health.',
    fullDescription: 'Led by Dr. Rajasekhar Tippireddy, we provide specialized treatment plans and monitoring for diabetes and related metabolic conditions.',
    steps: ['Diagnosis', 'Glucose Monitoring', 'Lifestyle Guidance', 'Medication Management'],
    recovery: 'Continuous monitoring and lifestyle adjustments are key to successful management.',
    sourceUrl: 'https://www.lanermc.org/community/lane-health-blog/understanding-the-3-types-of-diabetes'
  },
  {
    id: 5,
    title: 'High-Risk Pregnancy Care',
    icon: <ShieldCheck />,
    image: 'https://images.pexels.com/photos/7055925/pexels-photo-7055925.jpeg',
    description: 'Close monitoring and medical supervision for pregnancies requiring extra care.',
    fullDescription: 'We provide specialized care for high-risk pregnancies, ensuring closer monitoring and medical supervision to manage potential complications.',
    steps: ['Risk Assessment', 'Intensive Monitoring', 'Specialized Testing', 'Safety Planning'],
    recovery: 'Requires frequent checkups and adherence to medical advice for safety.',
    sourceUrl: 'https://motherlandhospital.com/medical-care-for-mothers-during-high-risk-pregnancy/'
  },
  {
    id: 6,
    title: 'Family Planning Services',
    icon: <Zap />,
    image: 'https://images.pexels.com/photos/3845126/pexels-photo-3845126.jpeg',
    description: 'Temporary contraception methods and permanent sterilization procedures.',
    fullDescription: 'We offer comprehensive family planning services, including counseling on temporary methods and performing permanent sterilization procedures.',
    steps: ['Counseling', 'Method Selection', 'Procedure/Prescription', 'Follow-up Care'],
    recovery: 'Recovery depends on the chosen method; surgical procedures may require a few days.',
    sourceUrl: 'https://drankeshsahetya.whitecoats.com/treatments/family-planning-services/'
  }
];

export default function Services() {
  const [selectedService, setSelectedService] = useState<typeof services[0] | null>(null);

  return (
    <section id="services" className="py-24 bg-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-primary-start font-bold tracking-wider uppercase text-sm mb-4 block"
          >
            Our Services
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl lg:text-5xl font-display font-bold text-dark-text mb-6"
          >
            Comprehensive Healthcare <br />
            <span className="text-gradient">For Women & Families</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-light-text max-w-2xl mx-auto"
          >
            We offer a wide range of medical services to ensure the health and wellbeing of your entire family.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group bg-soft-bg rounded-[2rem] overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 w-12 h-12 gradient-bg rounded-xl flex items-center justify-center text-white shadow-lg">
                  {service.icon}
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-dark-text mb-4 group-hover:text-primary-start transition-colors">
                  {service.title}
                </h3>
                <p className="text-light-text mb-6 line-clamp-2">
                  {service.description}
                </p>
                <button
                  onClick={() => setSelectedService(service)}
                  className="flex items-center space-x-2 text-primary-start font-bold hover:space-x-4 transition-all"
                >
                  <span>View Details</span>
                  <ArrowRight size={18} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Service Modal */}
      <AnimatePresence>
        {selectedService && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
              onClick={() => setSelectedService(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-4xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
            >
              <button
                onClick={() => setSelectedService(null)}
                className="absolute top-6 right-6 z-10 p-2 bg-white/80 backdrop-blur-md rounded-full text-dark-text hover:bg-primary-start hover:text-white transition-all shadow-lg"
              >
                <X size={24} />
              </button>

              <div className="grid lg:grid-cols-2">
                <div className="h-64 lg:h-auto">
                  <img
                    src={selectedService.image}
                    alt={selectedService.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-6 sm:p-8 lg:p-12">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4 mb-6">
                    <div className="w-14 h-14 gradient-bg rounded-2xl flex items-center justify-center text-white shadow-xl flex-shrink-0">
                      {selectedService.icon}
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-display font-bold text-dark-text">
                      {selectedService.title}
                    </h2>
                  </div>
                  
                  <p className="text-lg text-light-text mb-8 leading-relaxed">
                    {selectedService.fullDescription}
                  </p>

                  <div className="mb-8">
                    <h4 className="font-bold text-dark-text mb-4 flex items-center space-x-2">
                      <span className="w-1.5 h-6 gradient-bg rounded-full" />
                      <span>Procedure Steps</span>
                    </h4>
                    <ul className="grid sm:grid-cols-2 gap-3">
                      {selectedService.steps.map((step, i) => (
                        <li key={i} className="flex items-center space-x-2 text-light-text">
                          <span className="w-6 h-6 rounded-full bg-primary-start/10 text-primary-start text-xs flex items-center justify-center font-bold">
                            {i + 1}
                          </span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-10 p-6 bg-soft-bg rounded-2xl border border-primary-start/10">
                    <h4 className="font-bold text-dark-text mb-2">Recovery Information</h4>
                    <p className="text-light-text mb-4">{selectedService.recovery}</p>
                    {selectedService.sourceUrl && (
                      <a 
                        href={selectedService.sourceUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary-start text-sm font-bold hover:underline flex items-center space-x-1"
                      >
                        <span>Learn more from our resources</span>
                        <ArrowRight size={14} />
                      </a>
                    )}
                  </div>

                  <a
                    href="#contact"
                    onClick={() => setSelectedService(null)}
                    className="block w-full text-center gradient-bg text-white py-4 rounded-2xl font-bold shadow-xl hover:shadow-primary-start/40 transition-all hover:scale-[1.02]"
                  >
                    Book Appointment for {selectedService.title}
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
