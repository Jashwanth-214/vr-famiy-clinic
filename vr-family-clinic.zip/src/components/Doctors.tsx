import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Linkedin, Twitter, Instagram, Mail } from 'lucide-react';

const doctors = [
  {
    id: 1,
    name: 'Dr. Rashmi',
    role: 'Consultant Obstetrician, Gynecologist & Infertility Specialist',
    image: 'https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg',
    bio: 'Experienced Consultant specializing in pregnancy care, gynecology, and infertility treatment with FMAS and DRM certifications.',
    education: 'MBBS, DNB (OBG), DRM, FMAS',
    specialties: ['Pregnancy Care', 'Gynecology', 'Infertility Treatment'],
    social: { linkedin: '#', twitter: '#', instagram: '#' }
  },
  {
    id: 2,
    name: 'Dr. Rajasekhar Tippireddy',
    role: 'General Physician',
    image: 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg',
    bio: 'Dedicated General Physician with specialized expertise in diabetes diagnosis and management.',
    education: 'MBBS, Diploma in Diabetes',
    specialties: ['General Medicine', 'Diabetes Management', 'Family Health'],
    social: { linkedin: '#', twitter: '#', instagram: '#' }
  }
];

export default function Doctors() {
  const [selectedDoctor, setSelectedDoctor] = useState<typeof doctors[0] | null>(null);

  return (
    <section id="doctors" className="py-24 bg-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-primary-start font-bold tracking-wider uppercase text-sm mb-4 block"
          >
            Our Experts
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl lg:text-5xl font-display font-bold text-dark-text mb-6"
          >
            Meet Our <span className="text-gradient">Specialist Doctors</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-light-text max-w-2xl mx-auto"
          >
            Our team consists of highly qualified specialists dedicated to providing the best possible care for your family.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 max-w-4xl mx-auto gap-8">
          {doctors.map((doctor, index) => (
            <motion.div
              key={doctor.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative bg-white rounded-[2.5rem] p-8 shadow-lg hover:shadow-2xl transition-all duration-300 text-center"
            >
              <div
                className="relative w-48 h-48 mx-auto mb-6 rounded-full overflow-hidden border-4 border-primary-start/10 cursor-pointer"
                onClick={() => setSelectedDoctor(doctor)}
              >
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-primary-start/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="text-white font-bold">View Profile</span>
                </div>
              </div>

              <h3 className="text-2xl font-bold text-dark-text mb-1">{doctor.name}</h3>
              <p className="text-primary-start font-semibold text-sm mb-4">{doctor.role}</p>

              <div className="flex justify-center space-x-4 opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0">
                <a href={doctor.social.linkedin} className="text-light-text hover:text-primary-start transition-colors">
                  <Linkedin size={20} />
                </a>
                <a href={doctor.social.twitter} className="text-light-text hover:text-primary-start transition-colors">
                  <Twitter size={20} />
                </a>
                <a href={doctor.social.instagram} className="text-light-text hover:text-primary-start transition-colors">
                  <Instagram size={20} />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Doctor Modal */}
      <AnimatePresence>
        {selectedDoctor && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
              onClick={() => setSelectedDoctor(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <button
                onClick={() => setSelectedDoctor(null)}
                className="absolute top-6 right-6 z-10 p-2 bg-soft-bg rounded-full text-dark-text hover:bg-primary-start hover:text-white transition-all"
              >
                <X size={24} />
              </button>

              <div className="p-8 lg:p-12">
                <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8 mb-8">
                  <div className="w-40 h-40 rounded-3xl overflow-hidden border-4 border-primary-start/10 flex-shrink-0 shadow-xl">
                    <img
                      src={selectedDoctor.image}
                      alt={selectedDoctor.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="text-center md:text-left">
                    <h2 className="text-3xl font-display font-bold text-dark-text mb-2">
                      {selectedDoctor.name}
                    </h2>
                    <p className="text-primary-start font-bold text-lg mb-4">{selectedDoctor.role}</p>
                    <div className="flex justify-center md:justify-start space-x-4">
                      <a href="#" className="p-2 bg-soft-bg rounded-lg text-light-text hover:text-primary-start transition-colors">
                        <Linkedin size={20} />
                      </a>
                      <a href="#" className="p-2 bg-soft-bg rounded-lg text-light-text hover:text-primary-start transition-colors">
                        <Twitter size={20} />
                      </a>
                      <a href="#" className="p-2 bg-soft-bg rounded-lg text-light-text hover:text-primary-start transition-colors">
                        <Instagram size={20} />
                      </a>
                      <a href="#" className="p-2 bg-soft-bg rounded-lg text-light-text hover:text-primary-start transition-colors">
                        <Mail size={20} />
                      </a>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="font-bold text-dark-text mb-2">Biography</h4>
                    <p className="text-light-text leading-relaxed">{selectedDoctor.bio}</p>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-bold text-dark-text mb-2">Education</h4>
                      <p className="text-light-text">{selectedDoctor.education}</p>
                    </div>
                    <div>
                      <h4 className="font-bold text-dark-text mb-2">Specialties</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedDoctor.specialties.map((s) => (
                          <span key={s} className="px-3 py-1 bg-primary-start/10 text-primary-start text-xs font-bold rounded-full">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedDoctor(null)}
                  className="mt-10 w-full gradient-bg text-white py-4 rounded-2xl font-bold shadow-xl hover:shadow-primary-start/40 transition-all"
                >
                  Schedule Consultation
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
