import { motion, useInView } from 'motion/react';
import { useRef, useState, useEffect } from 'react';
import { UserCheck, Clock, Smile, Award } from 'lucide-react';

const stats = [
  { id: 1, label: 'Happy Families', value: 2000, suffix: '+', icon: <Smile /> },
  { id: 2, label: 'Years Experience', value: 15, suffix: '+', icon: <Clock /> },
  { id: 3, label: 'Satisfaction Rate', value: 99, suffix: '%', icon: <Award /> },
  { id: 4, label: 'Expert Doctors', value: 5, suffix: '+', icon: <UserCheck /> },
];

function Counter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = value;
      const duration = 2000;
      const increment = end / (duration / 16);
      
      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 16);
      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return (
    <span ref={ref} className="text-4xl lg:text-5xl font-display font-bold text-white">
      {count}{suffix}
    </span>
  );
}

export default function WhyChooseUs() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background with Gradient and Image Overlay */}
      <div className="absolute inset-0 bg-primary-start/80 backdrop-blur-sm -z-10" />
      <div className="absolute inset-0 bg-black/20 -z-10" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-white/80 font-bold tracking-wider uppercase text-sm mb-4 block">
              Why Choose Us
            </span>
            <h2 className="text-4xl lg:text-5xl font-display font-bold text-white mb-8 leading-tight">
              Ethical Care <br />
              <span className="text-white/90">For Your Family</span>
            </h2>
            <p className="text-lg text-white/70 mb-12 leading-relaxed max-w-xl">
              We combine specialized expertise with a commitment to transparent medical services, ensuring patient comfort and avoiding unnecessary investigations.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {stats.map((stat) => (
                <div key={stat.id} className="flex flex-col">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-white mb-4 backdrop-blur-md">
                    {stat.icon}
                  </div>
                  <Counter value={stat.value} suffix={stat.suffix} />
                  <p className="text-white/60 font-medium mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white/10">
              <img
                src="https://picsum.photos/seed/modern-clinic/800/600"
                alt="Modern Clinic"
                className="w-full h-auto object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            
            {/* Floating Achievement */}
            <motion.div
              animate={{ y: [0, 20, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-10 -right-10 glass-card p-8 rounded-3xl hidden md:block"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 mb-4">
                  <Award size={32} />
                </div>
                <p className="font-bold text-dark-text text-xl">Best Family Clinic</p>
                <p className="text-sm text-light-text">Excellence Award 2025</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
