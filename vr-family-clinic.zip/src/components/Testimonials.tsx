import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Verified Patient',
    role: 'Practo Review',
    image: 'https://picsum.photos/seed/patient-v1/200/200',
    rating: 5,
    text: 'Dr. Rashmi is incredibly patient and thorough. She guided me through my entire pregnancy journey with such care. The clinic is very clean and professional.'
  },
  {
    id: 2,
    name: 'Verified Patient',
    role: 'Justdial Review',
    image: 'https://picsum.photos/seed/patient-v2/200/200',
    rating: 5,
    text: 'Highly recommend Dr. Rajasekhar for diabetes management. He explains everything clearly and doesn’t prescribe unnecessary tests. Very ethical practice.'
  },
  {
    id: 3,
    name: 'Verified Patient',
    role: 'Google Review',
    image: 'https://picsum.photos/seed/patient-v3/200/200',
    rating: 5,
    text: 'The best clinic for women’s health in Yelahanka. The staff is friendly, and the doctors are very experienced. I felt very comfortable during my consultations.'
  },
  {
    id: 4,
    name: 'Verified Patient',
    role: 'Practo Review',
    image: 'https://picsum.photos/seed/patient-v4/200/200',
    rating: 5,
    text: 'Excellent infertility treatment. We had a great experience with Dr. Rashmi. She is very knowledgeable and provided us with a personalized care plan.'
  }
];

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const next = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  }, []);

  const prev = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  }, []);

  useEffect(() => {
    if (!isPaused) {
      const timer = setInterval(next, 5000);
      return () => clearInterval(timer);
    }
  }, [isPaused, next]);

  return (
    <section className="py-24 bg-transparent overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-primary-start font-bold tracking-wider uppercase text-sm mb-4 block"
          >
            Testimonials
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl lg:text-5xl font-display font-bold text-dark-text mb-6"
          >
            What Our <span className="text-gradient">Patients Say</span>
          </motion.h2>
        </div>

        <div
          className="relative max-w-4xl mx-auto"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="bg-soft-bg rounded-[3rem] p-8 md:p-16 shadow-xl relative"
            >
              <div className="absolute top-10 right-10 text-primary-start/10 hidden sm:block">
                <Quote size={120} />
              </div>
              <div className="absolute top-6 right-6 text-primary-start/10 sm:hidden">
                <Quote size={60} />
              </div>

              <div className="relative z-10">
                <div className="flex items-center space-x-1 mb-6">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <Star key={i} size={20} className="fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                <p className="text-xl md:text-2xl text-dark-text font-medium italic mb-10 leading-relaxed">
                  "{testimonials[currentIndex].text}"
                </p>

                <div className="flex items-center space-x-6">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-lg">
                    <img
                      src={testimonials[currentIndex].image}
                      alt={testimonials[currentIndex].name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-dark-text">{testimonials[currentIndex].name}</h4>
                    <p className="text-primary-start font-medium">{testimonials[currentIndex].role}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Buttons */}
          <div className="flex justify-center mt-12 space-x-4">
            <button
              onClick={prev}
              className="w-14 h-14 rounded-full border-2 border-primary-start/20 flex items-center justify-center text-primary-start hover:bg-primary-start hover:text-white transition-all shadow-lg"
            >
              <ChevronLeft size={24} />
            </button>
            <button
              onClick={next}
              className="w-14 h-14 rounded-full border-2 border-primary-start/20 flex items-center justify-center text-primary-start hover:bg-primary-start hover:text-white transition-all shadow-lg"
            >
              <ChevronRight size={24} />
            </button>
          </div>

          {/* Indicators */}
          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === currentIndex ? 'w-8 bg-primary-start' : 'w-2 bg-primary-start/20'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
