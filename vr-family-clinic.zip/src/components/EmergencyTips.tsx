import { motion } from 'motion/react';
import { AlertCircle, Zap, ShieldAlert } from 'lucide-react';

const tips = [
  {
    id: 1,
    title: 'Severe Abdominal Pain',
    icon: <AlertCircle />,
    color: 'bg-red-100 text-red-600',
    description: 'During pregnancy, severe or persistent abdominal pain should be reported immediately. Contact the clinic or visit the nearest emergency center.'
  },
  {
    id: 2,
    title: 'Reduced Fetal Movement',
    icon: <Zap />,
    color: 'bg-orange-100 text-orange-600',
    description: 'If you notice a significant decrease in your baby’s movements, perform a kick count and contact your doctor immediately.'
  },
  {
    id: 3,
    title: 'Sudden Swelling',
    icon: <ShieldAlert />,
    color: 'bg-blue-100 text-blue-600',
    description: 'Sudden swelling of the face, hands, or feet can be a sign of preeclampsia. Monitor your blood pressure and seek medical advice.'
  }
];

export default function EmergencyTips() {
  return (
    <section className="py-24 bg-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-red-500 font-bold tracking-wider uppercase text-sm mb-4 block"
          >
            Emergency Care
          </motion.span>
          <h2 className="text-4xl lg:text-5xl font-display font-bold text-dark-text mb-6">
            Health Emergency? <span className="text-gradient">Quick Tips</span>
          </h2>
          <p className="text-lg text-light-text max-w-2xl mx-auto">
            In case of a medical emergency, stay calm and follow these immediate steps before heading to our clinic.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {tips.map((tip, index) => (
            <motion.div
              key={tip.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-white p-8 rounded-[2.5rem] shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100"
            >
              <div className={`w-16 h-16 ${tip.color} rounded-2xl flex items-center justify-center mb-6 shadow-inner`}>
                {tip.icon}
              </div>
              <h3 className="text-2xl font-bold text-dark-text mb-4">{tip.title}</h3>
              <p className="text-light-text leading-relaxed">
                {tip.description}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center px-4">
          <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 p-6 sm:p-8 bg-white rounded-3xl shadow-xl border border-red-100 max-w-2xl mx-auto">
            <div className="w-14 h-14 bg-red-500 rounded-full flex items-center justify-center text-white animate-pulse flex-shrink-0">
              <Zap size={28} />
            </div>
            <div className="text-center sm:text-left">
              <p className="text-sm font-bold text-red-500 uppercase tracking-wider">Emergency Hotline</p>
              <p className="text-2xl sm:text-3xl font-display font-bold text-dark-text">+91 97391 36066</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
