import { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Environment } from '@react-three/drei';
import * as THREE from 'three';

function AnimatedSphere({ position, color, scale, speed, distort, radius }: any) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.getElapsedTime() * 0.2;
      meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.3;
    }
  });

  return (
    <Float speed={speed} rotationIntensity={1} floatIntensity={2}>
      <mesh ref={meshRef} position={position} scale={scale}>
        <sphereGeometry args={[radius, 64, 64]} />
        <MeshDistortMaterial
          color={color}
          envMapIntensity={1}
          clearcoat={1}
          clearcoatRoughness={0.1}
          metalness={0.1}
          roughness={0.4}
          distort={distort}
          speed={speed}
          transparent
          opacity={0.6}
        />
      </mesh>
    </Float>
  );
}

export default function Background3D() {
  return (
    <div className="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
      <Canvas camera={{ position: [0, 0, 10], fov: 45 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} color="#ffffff" />
        <directionalLight position={[-10, -10, -5]} intensity={0.5} color="#0F5EF7" />
        
        {/* Top Right Sphere */}
        <AnimatedSphere 
          position={[5, 4, -5]} 
          color="#3BA3FF" 
          scale={1} 
          speed={2} 
          distort={0.4} 
          radius={2.5} 
        />
        
        {/* Bottom Left Sphere */}
        <AnimatedSphere 
          position={[-6, -3, -8]} 
          color="#0F5EF7" 
          scale={1.2} 
          speed={1.5} 
          distort={0.5} 
          radius={3} 
        />
        
        {/* Center Background Sphere */}
        <AnimatedSphere 
          position={[0, 0, -15]} 
          color="#1E88E5" 
          scale={2} 
          speed={1} 
          distort={0.3} 
          radius={4} 
        />

        {/* Small Floating Orbs */}
        <AnimatedSphere 
          position={[4, -4, -2]} 
          color="#ffffff" 
          scale={0.5} 
          speed={3} 
          distort={0.2} 
          radius={1} 
        />
        <AnimatedSphere 
          position={[-4, 5, -4]} 
          color="#F7FAFF" 
          scale={0.7} 
          speed={2.5} 
          distort={0.3} 
          radius={1.2} 
        />

        <Environment preset="city" />
      </Canvas>
    </div>
  );
}
