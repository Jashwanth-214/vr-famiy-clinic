import { motion } from 'motion/react';
import { CheckCircle2, ShieldCheck, Eye, Heart, Award } from 'lucide-react';

const features = [
  'Expert Pregnancy & Antenatal Care',
  'Advanced Infertility Solutions',
  'Specialized Diabetes Management',
  'Ethical & Transparent Medical Services',
];

const values = [
  {
    icon: <ShieldCheck className="text-primary-start" size={32} />,
    title: 'Ethical Care',
    desc: 'No unnecessary tests or medications.',
    color: 'bg-blue-500/10',
    delay: 0.1
  },
  {
    icon: <Eye className="text-accent" size={32} />,
    title: 'Transparency',
    desc: 'Clear communication at every step.',
    color: 'bg-purple-500/10',
    delay: 0.2
  },
  {
    icon: <Heart className="text-red-500" size={32} />,
    title: 'Patient First',
    desc: 'Your comfort is our top priority.',
    color: 'bg-red-500/10',
    delay: 0.3
  },
  {
    icon: <Award className="text-yellow-600" size={32} />,
    title: 'Expertise',
    desc: 'Highly qualified specialist doctors.',
    color: 'bg-yellow-500/10',
    delay: 0.4
  }
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-soft-bg/50 backdrop-blur-sm overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Creative Values Mosaic Column */}
          <div className="relative h-auto md:h-[600px] py-12 md:py-0">
            {/* Decorative Background Glows */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full gradient-bg opacity-10 blur-[100px] rounded-full" />
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 h-full">
              {values.map((val, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30, scale: 0.9 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ 
                    duration: 0.8, 
                    delay: val.delay,
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ y: -10, scale: 1.05 }}
                  className={`relative p-8 rounded-[2.5rem] border border-white/20 backdrop-blur-xl shadow-2xl flex flex-col justify-center items-center text-center group ${val.color} ${
                    i === 1 ? 'sm:mt-12' : i === 2 ? 'sm:-mt-12' : ''
                  }`}
                >
                  <div className="mb-6 p-4 bg-white rounded-2xl shadow-inner group-hover:scale-110 transition-transform duration-300">
                    {val.icon}
                  </div>
                  <h3 className="text-xl font-bold text-dark-text mb-2">{val.title}</h3>
                  <p className="text-sm text-light-text leading-relaxed">{val.desc}</p>
                  
                  {/* Subtle Glow on Hover */}
                  <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                </motion.div>
              ))}
            </div>

            {/* Floating Badge */}
            <motion.div
              animate={{ 
                y: [0, -10, 0],
                rotate: [0, 5, 0]
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 glass-card px-8 py-4 rounded-full shadow-2xl border border-primary-start/20"
            >
              <span className="text-primary-start font-bold whitespace-nowrap">Trusted by 5000+ Families</span>
            </motion.div>
          </div>

          {/* Text Column */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-primary-start font-bold tracking-wider uppercase text-sm mb-4 block">
              About the Clinic
            </span>
            <h2 className="text-4xl lg:text-5xl font-display font-bold text-dark-text mb-2 leading-tight">
              VR Family Clinic
            </h2>
            <p className="text-primary-start font-bold text-lg mb-8 italic">Women’s & Family Healthcare Center</p>
            
            <p className="text-lg text-light-text mb-8 leading-relaxed">
              VR Family Clinic is a comprehensive healthcare center located in Yelahanka New Town, Bengaluru. We focus on providing high-quality medical care in areas such as pregnancy care, gynecology, infertility treatment, diabetes management, and general family health.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 mb-10">
              {features.map((feature) => (
                <div key={feature} className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary-start/10 flex items-center justify-center text-primary-start">
                    <CheckCircle2 size={16} />
                  </div>
                  <span className="text-dark-text font-medium text-sm">{feature}</span>
                </div>
              ))}
            </div>

            <p className="text-light-text mb-8 leading-relaxed italic">
              "Our goal is to deliver ethical and transparent medical services while ensuring patient comfort and avoiding unnecessary medications or investigations."
            </p>

            <button className="gradient-bg text-white px-10 py-4 rounded-full font-bold shadow-xl hover:shadow-primary-start/40 transition-all hover:scale-105 active:scale-95">
              Book a Consultation
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
