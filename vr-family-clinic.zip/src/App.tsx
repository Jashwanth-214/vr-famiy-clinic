import { useEffect, useState } from 'react';
import { motion, useScroll, useSpring } from 'motion/react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Doctors from './components/Doctors';
import Testimonials from './components/Testimonials';
import Blog from './components/Blog';
import FAQ from './components/FAQ';
import EmergencyTips from './components/EmergencyTips';
import AppointmentForm from './components/AppointmentForm';
import Footer from './components/Footer';
import Background3D from './components/Background3D';

export default function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  if (!isLoaded) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
      className="relative"
    >
      {/* 3D Background */}
      <Background3D />

      {/* Scroll Progress Indicator */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1.5 gradient-bg z-[60] origin-left"
        style={{ scaleX }}
      />

      <Header />
      
      <main>
        <Hero />
        <About />
        <Services />
        <WhyChooseUs />
        <Doctors />
        <Testimonials />
        <Blog />
        <FAQ />
        <EmergencyTips />
        <AppointmentForm />
      </main>

      <Footer />

      {/* Back to Top Floating Button is handled inside Footer for simplicity, 
          but could be a separate component if needed. */}
    </motion.div>
  );
}
